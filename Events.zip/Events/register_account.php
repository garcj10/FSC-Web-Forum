<?php 
include('header2.php'); 

//Include functions
include('functions.php');

?>

<?php
/************** Register new user ******************/


//require database class files
require('pdocon.php');


//instatiating our database objects
$db = new Pdocon;

if(isset($_POST['submit_login'])){

    $raw_firstName      =   cleandata($_POST['firstName']);
    $raw_lastName       =   cleandata($_POST['lastName']);
    $raw_email          =   cleandata($_POST['email']);
    $raw_password       =   cleandata($_POST['password']);
    
    
    $c_firstName             =   sanitize($raw_firstName);
    $c_lastName              =   sanitize($raw_lastName);
    $c_email            =   valemail($raw_email);
    $c_password         =   sanitize($raw_password);
    
    $hashed_Pass        =   hashpassword($c_password);
    
    
    $db->query("SELECT * FROM fsc_Users WHERE email = :email");
    
    $db->bindvalue(':email', $c_email, PDO::PARAM_STR);
    
    $row = $db->fetchSingle();
    
    if($row){
        
        echo '<div class="alert alert-danger text-center">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              User already exists. Please <a href="index.php"> Login.</a>
            </div>';
        
    }else{
        
        $db->query("INSERT INTO fsc_Users(user_Id, first_Name, last_Name, email, password) VALUES(NULL, :firstName, :lastName, :email, :password)");
        
        $db->bindvalue(':firstName', $c_firstName, PDO::PARAM_STR);
        $db->bindvalue(':lastName', $c_lastName, PDO::PARAM_STR);
        $db->bindvalue(':email', $c_email, PDO::PARAM_STR);
        $db->bindvalue(':password', $hashed_Pass, PDO::PARAM_STR);
        
        $run = $db->execute();
        
        if($run){
            
            echo '<div class="alert alert-success text-center">
                  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                  <strong>Success!</strong> Registered successfully.  Please Login
                  </div>';
            
        }else{
            
             echo '<div class="alert alert-danger text-center">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Sorry!</strong> User could not be registered. Please try again later
            </div>';
        }
    }
}

?>

    <div class="row">
      <div class="col-md-4 col-md-offset-4">
          <p class=""><a class="pull-right" href="index.php"> Login</a></p><br>
      </div>
      <div class="col-md-4 col-md-offset-4">
        <form class="form-horizontal" role="form" method="post" action="register_account.php" enctype="multipart/form-data">
         <!-- First Name -->
          <div class="form-group">
            <label class="control-label col-sm-2" for="firstName"></label>
            <div class="col-sm-10">
              <input type="firstName" name="firstName" class="form-control" id="firstName" placeholder="Enter First Name" required>
            </div>
          </div>
          <!-- Last Name -->
          <div class="form-group">
              <label class="control-label col-sm-2" for="lastName"></label>
             <div class="col-sm-10">
              <input type="lastName" name="lastName" class="form-control" id="lastName" placeholder="Enter Last Name" required>
            </div>
            </div>
          <!-- Email -->
          <div class="form-group">
            <label class="control-label col-sm-2" for="email"></label>
            <div class="col-sm-10">
              <input type="email" name="email" class="form-control" id="email" placeholder="Enter Email" required>
            </div>
          </div>
          <!-- Password -->
          <div class="form-group">
            <label class="control-label col-sm-2" for="pwd"></label>
            <div class="col-sm-10"> 
              <input type="password" name="password" class="form-control" id="pwd" placeholder="Enter Password" required>
            </div>
          </div>
          <div class="form-group"> 
            <div class="col-sm-offset-2 col-sm-10">
              <div class="checkbox">
                <label><input type="checkbox" required> Accept </label>
              </div>
            </div>
          </div>
         <!-- Register/Cancel Buttons -->
          <div class="form-group"> 
            <div class="col-sm-offset-2 col-sm-10 text-center">
              <button type="submit" class="btn btn-primary pull-right" name="submit_login">Register</button>
              <a class="pull-left btn btn-danger" href="index.php"> Cancel</a>
            </div>
          </div>
</form> 
  </div>
</div>
  
<?php include('footer.php'); ?>  