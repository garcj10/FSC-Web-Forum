<?php 
// Contains Navigation bar
include('includes/header.php');

// Include functions:
include('includes/functions.php');

?>
 
<?php

// Requires your file with connection to the database:
require('includes/pdocon.php');
    
// Instantiate database object:
$db = new Pdocon;

// Collects and processes data once the user clicks submit:
if(isset($_POST['submit_login'])){
    
    $raw_email       =   cleandata($_POST['email']);
    
    $raw_password       =   cleandata($_POST['password']);
    
    $c_email             =   valemail($raw_email);            
    
    $hashed_password    =   hashpassword($raw_password);
      
    
    $db->query('SELECT * FROM fsc_Users WHERE email=:email AND password=:password');
    
    $db->bindValue(':email', $c_email, PDO::PARAM_STR);
    $db->bindValue(':password',$hashed_password, PDO::PARAM_STR);
    
    $row = $db->fetchSingle();
    
    if($row){
        
      
        $db_firstName   =   $row['firstName'];
    
// Creates a session with the logged in user's data. This session
// is necessary to withhold all the data between pages.
        
        $_SESSION['user_data'] = array(
    
        'firstName' => $row['first_Name'],
        'id' => $row['user_Id'],
        'email' => $row['email'],
        );
        
        $_SESSION['user_is_logged_in']  =  true;
        
        redirect('my_account.php');
        
        keepmsg('<div class="alert alert-success text-center">
                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                      <strong>Welcome </strong>' . $d_firstName . '
                </div>');
        
    } else {
        
         echo '<div class="alert alert-danger text-center">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>Sorry!</strong> User does not exist.
            </div>';

    }    
}

?>
  
  <div class="row">
      <div class="col-md-4 col-md-offset-4">
          <p class=""><a class="pull-right" href="register_admin.php"> Register</a></p><br>
      </div>
      <div class="col-md-4 col-md-offset-4">
        <form class="form-horizontal" role="form" method="post" action="index.php">
          <div class="form-group">
            <label class="control-label col-sm-2" for="email"></label>
            <div class="col-sm-10">
              <input type="email" name="email" class="form-control" id="email" placeholder="Enter Email" required>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-sm-2" for="pwd"></label>
            <div class="col-sm-10"> 
              <input type="password" name="password" class="form-control" id="pwd" placeholder="Enter Password" required>
            </div>
          </div>

          <div class="form-group"> 
            <div class="col-sm-offset-2 col-sm-10 text-center">
              <button type="submit" class="btn btn-primary text-center" name="submit_login">Login</button>
            </div>
          </div>
        </form>
          
  </div>
</div>
  
<?php include('includes/footer.php'); ?>